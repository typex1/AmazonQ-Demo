import pandas as pd
# open a csv file and return the list of lines in alphabetical order
# remove duplicate lines
# insert a period at the end of each line