import logging
# take a user's input using the input() function and store it in a variable called filename
