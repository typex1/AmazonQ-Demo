# function that accepts a path to a csv file and returns the content as a dictionary
