"""
Amazon Q Developer Immersion Day Basics - example 3
"""

import numpy

