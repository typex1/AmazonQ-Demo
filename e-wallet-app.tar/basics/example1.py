"""
Amazon Q Developer - E-wallet entries 
"""

fakeEWallets = {
  { "name": "wallet-1", "id": "00001", "balance": "100", "currency": "USD" },
}
